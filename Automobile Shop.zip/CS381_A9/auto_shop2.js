// Define a car object using a constructor function
//step-1: add js code to complete the definition of the following constructor function
function Car(stockid, make, model, year, type, color, price, milage, display) {
	this.stockid = stockid;
	this.make = make;
	this.model = model;
	this.year = year;
	this.type = type;
	this.color = color;
	this.price = price;
	this.mileage = mileage;
	this.display = function(){
		var this_str = "<td>" + this.stockid + "</td><td>" + this.make + "</td>";
		this_str += "<td>" + this.model + "</td><td>" + this.year + "</td><td>" + this.type + "</td>";
		this_str += "<td>" + this.color + "</td><td> $" + this.price + "</td>";
		this_str += "<td>" + this.mileage + "</td>";
		return this_str;
	}
}


// Declare an array of objects
var car_list = [];  // var car_list = new Array();
var stockid, make, model, year, type, color, price, mileage, display;

// step 2. Use a for loop to read car info from web page
// and then create the Car object instances and 
// add individual car objects to the car_list array

var num = document.getElementsByClassName('car-item');
for (var i=0; i< num.length; i++) { // go through each car 
	// grab each element for the car 
	stockid = document.getElementById('id-'+ i).textContent;
	make = document.getElementById('make-'+ i).textContent;
	model = document.getElementById('model-'+ i).textContent;
	year = document.getElementById('year-'+ i).textContent;
	type = document.getElementById('type-'+ i).textContent;
	color = document.getElementById('color-'+ i).textContent;
	price = document.getElementById('price-'+ i).textContent;
	mileage = document.getElementById('mileage-'+ i).textContent;
	display = document.getElementById('select-'+ i).textContent;


	// create a new instance of the car 
	car_list.push(new Car(stockid, make, model, year, type, color, price, mileage, display));
}


//step 3. apply event delegation for Add buttons, 
//by registering event handler "addItem" function to the click event to <table id='car-list'> element 
 
//click event for add button
document.querySelector("table").addEventListener('click', addItem); 

 // define an array to hold the index of the car added to the shopping chart
 var cart = [];
 
 //Step 4: add js code to complete addItem() function
 //This  function defines an event handler that adds a car to shopping cart
 function addItem(e){
	//(1) Define a car index by using the value of the value attribute in each Add button element.  
	//(2) Save that car index into cart array. 
	//(3) use the car index to find the corresponding car object in the car_list array and then call addNewItemtoCart function to add selected car info (make, type, and price) into the shopping cart table. 

	let item = e.target; // grab the click item 
	if(item.classList.contains('add-item')) { // we don't want the user to click anywhere but the add button
		let index = parseInt(item.value); // grab the string value for the specific button's value attribute, and change it to an int 
		cart.push(index); // add index to the cart  
		console.log(index);
		console.log(car_list.length);
		console.log(car_list[index]);
		addNewItemtoCart(car_list[index]); // add product object that the user selects
	}
	
 }
 
//Step 4:(4) Add js code in addNewItemtoCart function to create three new <td> elements in shopping chart (‘mycart’) table and append them to a new table row in shop cart table to display make, 
//type, and price of the selected car.
 function addNewItemtoCart(item){
 /* This function creates and adds a new table row to an existing table
 */
	//create a new <tr> element: a table row
	var newTrElement = document.createElement('tr');
	
	//4.4.1:call createNewTdElement to create a <td> element using item.make as content
	//4.4.2: append it to the new tr element

	var newTdElement = createNewTdElement(item.make); // grab 
	newTrElement.appendChild(newTdElement); // append 
	
	//4.4.3: call createNewTdElement to create a <td> element using item.model as content
	//4.4.4: append it to the new tr element

	var newTdElement = createNewTdElement(item.model); // grab 
	newTrElement.appendChild(newTdElement); // append 

	//4.4.5: call createNewTdElement to create a <td> element using item.price as content
	//4.4.6: append it to the new tr element

	var newTdElement = createNewTdElement(item.price); // grab 
	newTrElement.appendChild(newTdElement); // append 

	//append new <tr> element to the shopping cart
	document.getElementById('mycart').appendChild(newTrElement);
 }
 
 function createNewTdElement(cell_content){
 /* This function creates and returns a new table cell using  the following steps:
	1. create a new text node using createTextNode() method
	2. create a new 'td' element using createElement() method
	3. append the newly created text node to the new 'td' element
	4. return the newly created 'td' element
 */
	// create a text node
	var newTextNode = document.createTextNode(cell_content);
	// create a new td element
	var newTdElement = document.createElement('td');
	// append text node to the new td element
	newTdElement.appendChild(newTextNode);
	return newTdElement;
 }
 
 
//Step 5(1)Add js code to complete definition of the displayInvoice function

//click event for invoice, display sedans, and reset button 
document.getElementById("p4").addEventListener('click', displayInvoice); 
document.getElementById("p2").addEventListener('click', displaySedan); 
document.getElementById("p5").addEventListener('click', reset); 

 function displayInvoice()
 {
	if (cart.length > 0) {
		document.getElementById('total-items').textContent = cart.length + ' Cars';

		var subtotalprice = 0;
		let saved = document.getElementById('mycart'); // view the cart
        let rows = saved.querySelectorAll('tr'); // select all tr elements (rows)
		for (let i = 0; i < cart.length; i++) {
			let price = rows[i+1].querySelectorAll('td'); // grab the price for each row (besides the first)
            console.log('price: ' + price[2].textContent); // Access the third column (index 2) for the price
            subtotalprice += parseFloat(price[2].textContent);
		}
		//console.log(subtotalprice);
		document.getElementById('sub-total').textContent = '$' + subtotalprice.toFixed(2);
		var taxes = subtotalprice * 0.06;

		//console.log(taxes);
		document.getElementById('taxes').textContent = '$' + taxes.toFixed(2);
		var registrationFee = subtotalprice * 0.05;

		//console.log(registrationFee);
		document.getElementById('registration').textContent = '$' + registrationFee.toFixed(2);
		var totalCost = subtotalprice + taxes + registrationFee;
		document.getElementById('total').textContent = '$' + totalCost.toFixed(2);


	} else {alert("Your Cart Is Empty!")}

	//use the car index in the cart array to find the corresponding car object in the car_list array, 
	//and then calculate the total number of items in the shopping cart, 
	//subtotal, 6% taxes, 5% registration fees, and total amount. 
	//Display all those invoice information in the invoice table on the web page. 
	//If the shopping cart is empty, display a pop-up message saying “Your cart is empty!” 
 }

 //Step 6 (1)Add js code to complete definition of the displaySedan function
function displaySedan()
{

	for (let i = 0; i < car_list.length; i++) {
		if (car_list[i].type == "Sedan") { // if the type is a sedan, use it
			var newTrElement = document.createElement('tr');
			newTrElement.innerHTML = car_list[i].display();
			document.getElementById('sedan-list').appendChild(newTrElement);
		}
		else {

		}
	}

	//use a for loop to access each car object in car_list array, and check each car's type property
	//if a car's type property has value "Sedan", then create a new <tr> element
	//and then add new content and table cells to new <tr> element by using innerHTML, 
	//call car object's display() method to assign a string to innerHTML.
}
function reset() { // resets entries 

	// reset cart 
    var mycart = document.getElementById('mycart'); 
    for (var i = mycart.children.length - 1; i > 0; i--) { // remove the children, but not the first
        mycart.removeChild(mycart.children[i]);
    }


	// reset sedan list

	var sedanlist = document.getElementById('sedan-list'); 
	for (var i = sedanlist.children.length - 1; i > 0; i--) { // remove the children, but not the first
        sedanlist.removeChild(sedanlist.children[i]);
    }

	// reset values 

	cart.length = 0;
	document.getElementById('total-items').textContent = 0;
	document.getElementById('sub-total').textContent = 0;
	document.getElementById('taxes').textContent = 0;
	document.getElementById('registration').textContent = 0;
	document.getElementById('total').textContent = 0;

}

