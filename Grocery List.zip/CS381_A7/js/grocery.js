
var elList, addLink, counter;      // Declare variables
var $ = function(id) { return document.getElementById(id); };
elList  = $('list');               // Get <ul> list                   
addLink = $('add');				   // Get add item button
counter = $('counter');            // Get item counter

function updateCount() { 		   // Define updateCount function
  var listItems;								
  listItems = elList.getElementsByTagName('li').length;  // Get total of <li>s
  counter.innerHTML = listItems;                         // Update counter
}

// Declare function to add an item in the list
function addItem() { 
//step1.1, 1.2: Create a prompt pop-up box by using prompt() method. Add a default text 
//in the prompt box when creating that prompt box. 
//The default text is: "add new item as nth item", where n is equal to the number of items in the grocery list + 1 

let totalItems = elList.getElementsByTagName('li');
let userInput = prompt("Add new item as the " + (totalItems.length + 1) + "th item below:", "Type item name here");

//step 1.3, 1.4: If users clicked the "OK" button in the prompt box without entering new text (i.e., if prompt box returns 
//a null) or without removing the default text (i.e., if prompt box returns default text), then an alert box will pop-up 
//and says "Did not enter a new item. Try again!".
if (userInput == null){
	// do nothing. User clicked cancel 
} else if (userInput == "" || userInput == "Type item name here") { 
// user cleared box and didn't type anything, or didn't update box at all 
alert("You forgot to enter a new item! Try again...");
addItem();
} else { // don't let the function continue if the user messes up their inputs 

//step 1.5: If users entered a name of new item and press the OK button in the prompt box, then 
//a new list item (i.e., a new <li> element with the text content which is the name that users entered) 
//will be added at the end in the grocery list on the web page. When adding a new item to the grocery list, 
//should also add a "delete" button inside that new item. The delete button is structured as <a href="#" class="delete">Delete</a>. 

var newItemIndex = elList.getElementsByTagName('li').length;
var newEl = document.createElement('li');                  		// New <li> element
var newContent = userInput;    									// New text content, using userInput

var deleteButton = document.createElement('a'); // create the elements needed for the button 
deleteButton.setAttribute('href', '#'); 
deleteButton.setAttribute('class', 'delete');
deleteButton.textContent = "Delete";
   
newEl.textContent = newContent;      							// Add text to <li>  
newEl.appendChild(deleteButton);                 				// add the button elements 
elList.appendChild(newEl);										// Add <li> to list

//step 1.6: After adding a new item to the list, update the number of groceries in the list by calling   updateCount function.

updateCount();
}
}

// create a function that remove <li> element which's delete button is clicked
function removeItem(e){  //step 2.1: Add a parameter in the function header to reference the event object. 
	//step 2.2: Set up an if statement so that only when a delete button (i.e., <a> element) is clicked, 
	//the related list item will be removed. 
	//a.In the if statement, use the event object to find the delete button that user clicked, and 
	//then delete the <li> element which contains that delete button.  
	//b. After deleting that grocery item, the updateCount function is used to update the number of groceries in the list. 
  
	//only if a delete button on the web page is clicked, then delete the list item 
  	if (e.target.nodeName.toLowerCase() == "a" ) {  // If user clicked on an <a> element
		let temp = e.target.parentNode.textContent; // grabs all text contents for the li element 
		let displayText = temp.replace('Delete', ''); // replace the end of the text "Delete" with nothing
		let result = confirm("Are you sure you want to delete " + displayText + "?");
		if(result == true) {
    		elListItem = e.target.parentNode;              // Get its li element
    		elList = elListItem.parentNode;              // Get the ul element
    		elList.removeChild(elListItem);              // Remove list item from list
			alert(displayText + " was deleted!");
		}
		else {
			alert(displayText + " was not deleted.");
		}
  	}

	updateCount();
}


addLink.addEventListener('click', addItem, false);       // Click on button

//step 3: Apply event delegation by using addEventListener() method of the <ul> element so that when any of 
//the delete buttons in the gerocery list is clicked,  removeItem function will be called as an event handler.  
//use event delegation to add event hander to <ul> element to delete each <li> element

var el = document.getElementById('list');			// Get shopping list
el.addEventListener('click', function(e) {     		// Add listener on click
    removeItem(e);                                 		// It calls removeItem();
  }, false);                                     		// Use bubbling phase for flow


